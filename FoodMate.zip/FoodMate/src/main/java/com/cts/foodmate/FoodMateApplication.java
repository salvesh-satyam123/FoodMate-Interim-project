package com.cts.foodmate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodMateApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodMateApplication.class, args);
	}

}
