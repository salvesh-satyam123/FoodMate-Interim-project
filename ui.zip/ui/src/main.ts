import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';

//invokes compiler and specifies startup module and also start executing the application.
platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
