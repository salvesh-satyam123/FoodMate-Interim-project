import { Iuser } from "./iuser";

export interface Iaddress {

    id:number;
	street:string;
	city:string;
	state:string;
    zipCode:string;

}
