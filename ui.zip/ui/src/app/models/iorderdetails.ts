export interface Iorderdetails {

    name:string;
	quantity:number;
	price:number;
}
