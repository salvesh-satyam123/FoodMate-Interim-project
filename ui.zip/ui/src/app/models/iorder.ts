import { Iorderdetails } from "./iorderdetails";

export interface Iorder {
   oid:number;
	 userId:number;
	 summary:string;
	address:string;
	calendarDate:Date;
	price:number;
	
	
description:Iorderdetails[]
	
	
	


}
