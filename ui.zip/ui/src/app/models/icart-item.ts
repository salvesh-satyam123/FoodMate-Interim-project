import { Iproduct } from "./iproduct";

export interface IcartItem {

    cartId:number;
    userId:number;
    product:Iproduct;
    quantity:number;
    inorder:boolean;
}
