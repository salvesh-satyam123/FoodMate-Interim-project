export interface Irevenue {

    fromDate:Date;
	toDate:Date;
    price:number;
}
