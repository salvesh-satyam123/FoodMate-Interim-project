export interface Iuser {
    id:number;
    emailId: string;
    password: string;
    name: string;
    role: string;


   
}
