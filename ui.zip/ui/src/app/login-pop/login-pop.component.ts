import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UserserviceService } from '../data-service/userservice.service';
import { Iuser } from '../models/iuser';

@Component({
  selector: 'app-login-pop',
  templateUrl: './login-pop.component.html',
  styleUrls: ['./login-pop.component.css']
})
export class LoginPopComponent implements OnInit{

message:string="";

constructor(private http:HttpClient,private router:Router,private userservice:UserserviceService)
{
}
  ngOnInit(): void {
    sessionStorage.removeItem("user-log");
    sessionStorage.removeItem("admin-log");
    sessionStorage.removeItem("jwt")
  }

  
onSubmit(login:{username:string,password:string}):void
 {
  let response:Iuser;
   this.userservice.generateToken(login).subscribe(
    
    data=>{
   
    console.log(data.tokenVal)

    sessionStorage.setItem('jwt',data.tokenVal);

    this.userservice.login().subscribe(data =>{
      let user=data as Iuser
      console.log(user)
      if(user.role==="USER")
      {
        sessionStorage.setItem("user-log",JSON.stringify(user))
        this.router.navigate(["/user"]);
      }
      if(user.role==="ADMIN")
      {
        sessionStorage.setItem("admin-log",JSON.stringify(user))
        this.router.navigateByUrl("admin/admin-dashboard/(aux:product)");
    
      }
    }
  )
},
(error)=>{
  if(error.status===403)
  {
    this.message="Wrong Credentials"
  }else{
    this.message=" Something went wrong"
  }
}
)
    
}
}





























































 //   response=data as Iuser;

      
    //     if(response.role=="user")
    //     {
    //     this.router.navigate(["/user"]);
    //     sessionStorage.setItem("user-log",JSON.stringify(response));
    //     }
    //     if(response.role=="admin")
    //     {
    //       this.router.navigateByUrl("admin/admin-dashboard/(aux:product)");

    //       sessionStorage.setItem("admin-log",JSON.stringify(response));
    //     }

    // },
    // (error)=>{
    //   if(error.status===404)
    //   {
    //     this.message="Wrong Credentials"
    //   }
    // }
