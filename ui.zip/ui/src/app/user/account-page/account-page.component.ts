import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { timer } from 'rxjs';
import { UserserviceService } from 'src/app/data-service/userservice.service';
import { Iuser } from 'src/app/models/iuser';

@Component({
  selector: 'app-account-page',
  templateUrl: './account-page.component.html',
  styleUrls: ['./account-page.component.css']
})
export class AccountPageComponent implements OnInit{

  constructor(private userService:UserserviceService){

  }
  @ViewChild('formup') formup!:NgForm;

  userValue:Iuser={
    role:'USER',
    emailId:'',
    name:'',
    password:'',
    id:0
  }

  
  ngOnInit(): void {

    this.userService.login().subscribe({
      next:(val)=>{
        timer(1000).subscribe(()=>{
          this.userValue=val
          if(this.formup)
            {
            this.formup.setValue({
              name:val.name,
              emailId:val.emailId,
              password:'',
              id:val.id
            })
          }
        })

      }
    })

    
    
  
    console.log(this.formup)
  }

  update(value:Iuser){
    if(value.password==='')
    {
      //console.log(value.password)
      this.userService.updateUser(value,'N').subscribe(
        {
          complete:()=>{
            this.ngOnInit()
          }
        }
      )
    }
    else{
      //console.log(value.password)
      this.userService.updateUser(value,'Y').subscribe({
        complete:()=>{
          this.ngOnInit()

        }
      })

    }
    
  }


}
