import { Component, OnInit,ViewChild,ElementRef, OnChanges, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CartserviceService } from 'src/app/data-service/cartservice.service';
import { ProductserviceService } from 'src/app/data-service/productservice.service';
import { Iproduct } from 'src/app/models/iproduct';
import { faTrash ,faArrowLeftLong,faPlus,faMinus} from '@fortawesome/free-solid-svg-icons';
import { Icart } from 'src/app/models/icart';
import { IcartItem } from 'src/app/models/icart-item';
import { CartItemserviceService } from 'src/app/data-service/cart-itemservice.service';
import { OrderserviceService } from 'src/app/data-service/orderservice.service';
import { AddressserviceService } from 'src/app/data-service/addressservice.service';
import { Iaddress } from 'src/app/models/iaddress';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit{


 deleteIcon=faTrash
 backIcon=faArrowLeftLong
 plusIcon=faPlus
 minusIcon=faMinus
 cartPrice:number=0
  cart:Icart;
  jsonstring:string|null
  cartitem:number=0
  cartitems:IcartItem[]=[]
  json:any
  address:string
  addressArray:Iaddress[]=[]
   

  productId:number[]=[]



 constructor(private router:Router,private cartservice:CartserviceService,private cartitemservice:CartItemserviceService,private orderservice:OrderserviceService,private addressservice:AddressserviceService)
 {

  

   
 }
 ngOnInit(){

    this.jsonstring=sessionStorage.getItem('user-log');

    if(this.jsonstring){
      const userid=JSON.parse(this.jsonstring).id;
      console.log(userid)
      
       this.cartservice.getCart(userid).subscribe({
        next:(val)=>{
          this.cartitems=val as IcartItem[]
        },error:()=>{
          alert("Error occured")
        },
        complete:()=>{
          this.cartitem=this.cartitems.length;
          this.calculatePrice()
        }
      })

      this.addressservice.getByUser(userid).subscribe({
        next:(value) =>{
          this.addressArray= value as Iaddress[]
            
        },
        error:()=>{
          alert("Error occured")
        }
      })
     

    }

  }
  
 updateQty(c:IcartItem,qty:number)
  {
    c.quantity=c.quantity+qty
    this.cartitemservice.updateCart(c).subscribe(
      {
        complete:()=>{
          this.calculatePrice();
        }
      }
    )

  }

  delete(c:IcartItem)
  {
    
    
    this.cartservice.deleteItem(c.cartId).subscribe(
      {
        complete:()=>{
          let i=this.cartitems.indexOf(c);
          this.cartitems.splice(i,1)
          this.cartitem=this.cartitems.length;
          this.calculatePrice();
        }
      }
    );
    
    
 

  }
  calculatePrice()
  {
    this.cartPrice=0;
    this.cartitems.forEach(element => {
      this.cartPrice+=element.product.price*element.quantity
    });
  }

  checkout()
  {

    this.orderservice.addToOrder(this.address,this.cartitems[0].userId).subscribe(
    
    )
    this.cartitems=[]
        this.cartPrice=0
        this.cartitem=0
        sessionStorage.setItem("check","1")
       this.router.navigateByUrl("user/checkout")
   
    

  }
  originalValue(address:Iaddress)
  {
    return address.street+" ,"+address.city+" ,"+address.state+" ,"+address.zipCode;

  }


  




  }

  

  

    


   

  