import { Component,Input, OnInit } from '@angular/core';
import { Iorderdetails } from 'src/app/models/iorderdetails';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit{

  @Input()orderDetails:Iorderdetails[]

  @Input()totalPrice:number

  constructor()
  {
  }
  ngOnInit(): void {
    console.log(this.orderDetails)
  }
  display()
  {

    console.log(this.orderDetails)
  }




}
