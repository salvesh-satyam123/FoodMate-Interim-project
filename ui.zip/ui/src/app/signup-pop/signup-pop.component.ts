import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserserviceService } from '../data-service/userservice.service';
import { Iuser } from '../models/iuser';
@Component({
  selector: 'app-signup-pop',
  templateUrl: './signup-pop.component.html',
  styleUrls: ['./signup-pop.component.css']
})



export class SignupPopComponent {

  constructor(private http: HttpClient, private userservice: UserserviceService) { }

  message: string;




  onSubmit = (data: any) => {

    data["role"] = "USER";


    console.log(data);

    this.userservice.signup(data as Iuser).subscribe({
     
      next:(val)=>{
      },
      error: (error) => {

        this.message = "Account Already Exists";
      },
      complete:()=>{

        this.message="Account Created"
      }
      


    });
  }


}




