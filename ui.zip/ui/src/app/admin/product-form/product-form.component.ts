import { Component,Input } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductserviceService } from 'src/app/data-service/productservice.service';
import { Iproduct } from 'src/app/models/iproduct';
@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent {
  product:Iproduct={
    productId:0,
    image:"",
    name:"",
    price:0
  };
    constructor(private productservice:ProductserviceService ,private router:Router)
    {

    }

add=(r:{name:string,
  image:string,
  price:number
})=>{

 
 console.log(this.product)
  this.product.productId=0;
  this.product.image=r.image;
  this.product.price=r.price;
  this.product.name=r.name


  
this.productservice.addProduct(this.product).subscribe(
 {
  next: ()=>{

  },
  error: (error) => {
    console.log("Unable to add");
  },
  complete: () => {
    console.log("Product added successfully");
  }
 }
  
);

//this.router.navigateByUrl('/admin-dashboard/(aux:product)');






}





}
