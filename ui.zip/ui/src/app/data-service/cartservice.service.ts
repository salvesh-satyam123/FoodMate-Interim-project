import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Icart } from '../models/icart';
import { Iproduct } from '../models/iproduct';
import { IcartItem } from '../models/icart-item';

@Injectable({
  providedIn: 'root'
})
export class CartserviceService {

  cart:Icart[]=[];

  constructor(private http:HttpClient) {}

  getById(data:number):Observable<Icart>
  {
    return this.http.get<Icart>('http://localhost:8083/cart-rest/getCart/'+data.toString())
  }
  getCart(userId:number)
  {
    return this.http.get(`http://localhost:8086/cart-rest/cart/${userId}`)
  }
  addToCart(data:IcartItem)
  {
    return this.http.post("http://localhost:8086/cart-rest/addCart",data)
  }
  deleteItem(cartId:number)
  {
    return this.http.delete(`http://localhost:8086/cart-rest/deleteCart/${cartId}`);

  }

  


}
