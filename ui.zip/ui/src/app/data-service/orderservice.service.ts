import { Injectable } from '@angular/core';
import { IcartItem } from '../models/icart-item';
import { HttpClient } from '@angular/common/http';
import { Iorder } from '../models/iorder';

@Injectable({
  providedIn: 'root'
})
export class OrderserviceService {

  constructor(private http:HttpClient) { }

  addToOrder(address:string,userId:number)
  {
    return this.http.post(`http://localhost:8086/order-rest/user/addOrder/${userId}?address=${address}`,null)
  }

  getByUserId(userId:number)
  {
    return this.http.get(`http://localhost:8086/order-rest/user/getUserOrder/${userId}`)

  }

  getByOrderId(id:number)
  {
    return this.http.get("http://localhost:8083/order-rest/get/"+id.toString())
  }

  getRevenue(date:string)
  {
    return this.http.get(`http://localhost:8086/order-rest/admin/getdailyRevenue?date=${date}`)

  }
  getRevenueMonthy(date1:string,date2:string)
  {
    return this.http.get(`http://localhost:8086/order-rest/admin/getRevenueMonthly?fromdate=${date1}&todate=${date2}`)

  }

}
