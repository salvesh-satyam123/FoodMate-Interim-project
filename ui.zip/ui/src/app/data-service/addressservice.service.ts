import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Iaddress } from '../models/iaddress';

@Injectable({
  providedIn: 'root'
})
export class AddressserviceService {

  constructor(private http:HttpClient) { }

  addAddress(data:any,
    userId:number)
  {
    return this.http.post(`http://localhost:8086/address-rest/addAddress/${userId}`,data)
  }

  getByUser(userId:number)
  {
    return this.http.get(`http://localhost:8086/address-rest/getAddress/${userId}`)
  }
  deleteAddress(addressId:number,userId:number)
  {
    return this.http.delete(`http://localhost:8086/address-rest/deleteAddress/${addressId}/${userId}`)
  }

  
}
