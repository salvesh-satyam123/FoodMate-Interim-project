import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Iuser } from '../models/iuser';
@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  constructor(private http:HttpClient) { 

  }


  signup=(data:Iuser)=>
  {
  
    return this.http.post('http://localhost:8086/auth/addNewUser',data);
  }

  generateToken=(data:{username:string,password:string})=>{
    return this.http.post<any>('http://localhost:8086/auth/generateToken',data);

  }
  login=()=>{
    return this.http.get<Iuser>('http://localhost:8086/auth/user/profile');

  }
  updateUser=(user:Iuser,isPasswordChange:string)=>{
    return this.http.put(`http://localhost:8086/auth/user/profile?isPasswordChange=${isPasswordChange}`,user);
  }

 
}
